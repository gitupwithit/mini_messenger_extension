console.log("service-worker.js loaded")

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "sendMessage") {
      console.log("sendMessage rec by service-worker")
      return true;
    }
    if (message.action === "signIn") {
        console.log("signIn rec by service-worker")
        return true;
      }
})