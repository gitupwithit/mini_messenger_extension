console.log("script.js loaded")

const inAndOutgoingMessagesContainer = document.getElementById('inAndOutgoingMessagesContainer')
const outgoingMessageForm = document.getElementById('outgoingMessageForm');
const messageToSend = document.getElementById('messageToSend');
const signInButton = document.getElementById('signInButton')
const signIn = document.getElementById('signIn')

outgoingMessageForm.addEventListener('submit', async function (event) {
    event.preventDefault();
    console.log('Form submitted');
    event.target.querySelector('button[type="submit"]').disabled = true;
    const data = { title: messageToSend.value }
    console.log("message to send: ", data)
    chrome.runtime.sendMessage({ action: "sendMessage" });
})

signInButton.addEventListener('click', async function (event) {
    event.preventDefault();
    // console.log('Sign In button pressed');
    // signInButton.disabled = true;
    signIn.style="display: none;"
    inAndOutgoingMessagesContainer.style="display: block;"
    chrome.runtime.sendMessage({ action: "userSignIn" });

})
